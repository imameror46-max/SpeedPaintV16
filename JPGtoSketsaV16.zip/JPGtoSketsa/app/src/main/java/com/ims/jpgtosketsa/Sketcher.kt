package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

class SketchParams(
    val mode: Int,    // 0 pensil hitam-putih, 1 pensil berwarna, 2 garis tegas, 3 pensil arsir, 4 arsir + AI
    val blur: Int,    // 0..100 ketebalan/kehalusan garis
    val dark: Int,    // 0..100 kegelapan / kekuatan garis
    val color: Int,   // 0..100 kekuatan warna (mode 1)
    val grain: Int,   // 0..100 tekstur kertas
    val paper: Int    // 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)
)

object Sketcher {
    /** Seperti render(), tapi foto kecil diperbesar dulu (mode Arsir) supaya goresan tetap halus. */
    fun renderHD(input: Bitmap, p: SketchParams): Bitmap {
        val big = max(input.width, input.height)
        if (p.mode < 3 || big >= 1400) return render(input, p)
        val f = 1400f / big
        val up = Bitmap.createScaledBitmap(input, (input.width * f).roundToInt(), (input.height * f).roundToInt(), true)
        return render(up, p)
    }

    fun render(src: Bitmap, p: SketchParams): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val scale = max(w, h) / 900f
        val gray = IntArray(n) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        val v = IntArray(n)

        if (p.mode == 3 || p.mode == 4) {
            hatch(gray, w, h, p, scale, v)
            if (p.mode == 4) {
                // Garis bentuk dari model AI portrait, dipadukan dengan arsiran
                val ai = AiPortrait.lines(src)
                if (ai != null) for (i in 0 until n) v[i] = (v[i] * (1f - 0.4f * (1f - ai[i] / 255f))).toInt()
            }
        } else if (p.mode == 2) {
            java.util.Arrays.fill(v, 255)
            val g = gray.copyOf()
            boxBlur(g, w, h, max(1, ((1f + p.blur * 0.12f) * scale).roundToInt()))
            val gain = 1.5f + p.dark * 0.06f
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
                val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
                v[i] = 255 - min(255, ((abs(gx) + abs(gy)) * gain / 2f).toInt())
            }
        } else {
            // Color dodge: gambar / (kebalikan gambar yang di-blur)
            val inv = IntArray(n) { 255 - gray[it] }
            boxBlur(inv, w, h, max(1, ((2f + p.blur * 0.38f) * scale).roundToInt()))
            val gamma = 0.6 + p.dark / 100.0 * 1.4
            val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma)).roundToInt().coerceIn(0, 255) }
            for (i in 0 until n) {
                val d = 256 - inv[i]
                v[i] = lut[min(255, gray[i] * 256 / max(1, d))]
            }
        }

        val out = IntArray(n)
        val colored = p.mode == 1
        val kc = p.color / 100f
        val gr = p.grain / 100f
        val pr: Float
        val pg: Float
        val pb: Float
        when (p.paper) {
            1 -> { pr = 245f; pg = 236f; pb = 215f }
            else -> { pr = 255f; pg = 255f; pb = 255f }
        }
        for (i in 0 until n) {
            val noise = ((i * -1640531535) ushr 24) / 255f
            val vv = v[i] * (1f - gr * 0.25f * noise)
            var lr = 255f
            var lg = 255f
            var lb = 255f
            if (colored) {
                val c = px[i]
                lr = 255f * (1f - kc) + Color.red(c) * kc
                lg = 255f * (1f - kc) + Color.green(c) * kc
                lb = 255f * (1f - kc) + Color.blue(c) * kc
            }
            if (p.paper == 3) {
                val al = (255f - vv).toInt().coerceIn(0, 255)
                out[i] = if (colored) Color.argb(al, (lr * 0.5f).toInt().coerceIn(0, 255), (lg * 0.5f).toInt().coerceIn(0, 255), (lb * 0.5f).toInt().coerceIn(0, 255))
                else Color.argb(al, 20, 20, 24)
                continue
            }
            val r: Float
            val g: Float
            val b: Float
            if (p.paper == 2) {
                val t = (255f - vv) / 255f
                r = 43f + (lr - 43f) * t
                g = 58f + (lg - 58f) * t
                b = 51f + (lb - 51f) * t
            } else {
                r = vv * lr / 255f * pr / 255f
                g = vv * lg / 255f * pg / 255f
                b = vv * lb / 255f * pb / 255f
            }
            out[i] = Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Pensil arsir: goresan searah bentuk (LIC), nada terang, arsiran padat hanya di area gelap, kontur tipis. */
    private fun hatch(gray: IntArray, w: Int, h: Int, p: SketchParams, scale: Float, v: IntArray) {
        val n = w * h
        val tone = gray.copyOf()
        boxBlur(tone, w, h, max(1, (0.6f * scale).roundToInt()))

        // Regangan kontras (persentil 1% - 99%)
        val hist = IntArray(256)
        for (i in 0 until n) hist[tone[i].coerceIn(0, 255)]++
        var lo = 0
        var acc = 0
        while (lo < 255 && acc + hist[lo] < n * 0.01f) { acc += hist[lo]; lo++ }
        var hi = 255
        acc = 0
        while (hi > 0 && acc + hist[hi] < n * 0.01f) { acc += hist[hi]; hi-- }
        if (hi - lo < 32) { lo = 0; hi = 255 }
        val inv = 1f / (hi - lo)
        val gamma = 1f / (0.55f + p.dark / 100f * 1.1f)

        // Auto-eksposur: foto gelap dicerahkan supaya wajah tidak tertutup arsiran
        var sumT = 0.0
        for (i in 0 until n) sumT += ((tone[i] - lo) * inv).coerceIn(0f, 1f)
        val mt = (sumT / n).toFloat().coerceIn(0.05f, 0.95f)
        val ex = (ln(0.58f) / ln(mt)).coerceIn(0.45f, 1f)
        val dLut = FloatArray(256) { tv -> (1f - (((tv - lo) * inv).coerceIn(0f, 1f)).pow(ex)).pow(gamma) }

        val dir = flowField(tone, w, h, scale)
        val cr = cos(0.65f)
        val sr = sin(0.65f)

        // Noise dasar: lebar sel = ketebalan goresan
        val cell = max(1, ((0.5f + p.blur * 0.01f) * scale).roundToInt())
        val noise = FloatArray(n)
        for (y in 0 until h) for (x in 0 until w) noise[y * w + x] = rnd((y / cell) * 100003 + (x / cell))

        val stp = max(1f, scale)
        for (y in 0 until h) {
            val fy = (y - h * 0.45f) / (h * 0.62f)
            for (x in 0 until w) {
                val i = y * w + x
                val d = dLut[tone[i].coerceIn(0, 255)]
                val ux = dir[2 * i] * stp
                val uy = dir[2 * i + 1] * stp

                // Lapis 1: goresan searah bentuk, hanya di area yang tidak terang
                var cov = 0f
                if (d > 0.08f) {
                    val l1 = licAt(noise, w, h, x, y, ux, uy, 6)
                    val h1 = (0.5f + (l1 - 0.5f) * 2.0f).coerceIn(0f, 1f)
                    cov = ((d - 0.10f - h1 * 0.9f) / 0.9f * 0.64f + 0.5f).coerceIn(0f, 1f) * sm(0.08f, 0.5f, d)
                }
                // Lapis 2: arsir silang untuk area benar-benar gelap
                if (d > 0.5f) {
                    val l2 = licAt(noise, w, h, x, y, ux * cr - uy * sr, ux * sr + uy * cr, 5)
                    val h2 = (0.5f + (l2 - 0.5f) * 2.0f).coerceIn(0f, 1f)
                    val c2 = ((d - 0.45f - h2 * 0.55f) / 0.495f + 0.5f).coerceIn(0f, 1f) * sm(0.5f, 0.8f, d)
                    cov = (cov + c2 * 0.5f).coerceIn(0f, 1f)
                }
                var dark = 0.6f * d.pow(1.2f) + 0.34f * cov

                // Kontur tipis (mata, bibir, tepi kain)
                if (x in 1 until w - 1 && y in 1 until h - 1) {
                    val gx = tone[i + 1] - tone[i - 1]
                    val gy = tone[i + w] - tone[i - w]
                    val e = (((abs(gx) + abs(gy)) * scale - 18f) / 80f).coerceIn(0f, 1f)
                    dark = max(dark, e * 0.42f * sm(0.05f, 0.3f, d + e * 0.3f))
                }

                // Tepi gambar memudar ke putih
                val fx = (x - w * 0.5f) / (w * 0.62f)
                dark *= 1f - 0.4f * sm(0.7f, 1.5f, fx * fx + fy * fy)

                v[i] = (255f * (1f - dark * 0.9f)).toInt().coerceIn(0, 255)
            }
        }
        if (scale >= 1f) softBlur(v, w, h)
    }

    /** Blur kotak 3x3 (satu lintasan) supaya goresan terasa seperti kuas lembut. */
    private fun softBlur(v: IntArray, w: Int, h: Int) {
        val t = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val a = v[y * w + max(x - 1, 0)]
            val b = v[y * w + x]
            val c = v[y * w + min(x + 1, w - 1)]
            t[y * w + x] = (a + b + c) / 3
        }
        for (y in 0 until h) for (x in 0 until w) {
            val a = t[max(y - 1, 0) * w + x]
            val b = t[y * w + x]
            val c = t[min(y + 1, h - 1) * w + x]
            v[y * w + x] = (a + b + c) / 3
        }
    }

    private fun sm(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Rata-rata noise sepanjang garis arah (dx, dy). */
    private fun licAt(noise: FloatArray, w: Int, h: Int, x: Int, y: Int, dx: Float, dy: Float, steps: Int): Float {
        var s = noise[y * w + x]
        for (k in 1..steps) {
            val ox = dx * k
            val oy = dy * k
            s += noise[(y + oy + 0.5f).toInt().coerceIn(0, h - 1) * w + (x + ox + 0.5f).toInt().coerceIn(0, w - 1)]
            s += noise[(y - oy + 0.5f).toInt().coerceIn(0, h - 1) * w + (x - ox + 0.5f).toInt().coerceIn(0, w - 1)]
        }
        return s / (2 * steps + 1)
    }

    /** Arah goresan per piksel (cos, sin berselang-seling): sejajar tepi, diagonal lembut di area datar. */
    private fun flowField(t: IntArray, w: Int, h: Int, scale: Float): FloatArray {
        val n = w * h
        val jxx = IntArray(n)
        val jyy = IntArray(n)
        val jxy = IntArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = t[i + 1] - t[i - 1]
            val gy = t[i + w] - t[i - w]
            jxx[i] = gx * gx; jyy[i] = gy * gy; jxy[i] = gx * gy
        }
        val r = max(2, (7f * scale).roundToInt())
        boxBlur(jxx, w, h, r); boxBlur(jyy, w, h, r); boxBlur(jxy, w, h, r)
        val out = FloatArray(2 * n)
        for (i in 0 until n) {
            val ax = (jxx[i] - jyy[i]).toFloat()
            val ay = 2f * jxy[i]
            val tr = jxx[i] + jyy[i] + 150f
            val ang = 0.5f * atan2(-ay / tr - 0.25f, -ax / tr)
            out[2 * i] = cos(ang)
            out[2 * i + 1] = sin(ang)
        }
        return out
    }

    private fun rnd(seed: Int): Float {
        var x = seed * -1640531535 + 0x2545F491
        x = x xor (x ushr 15); x *= 0x85ebca6b.toInt()
        x = x xor (x ushr 13); x *= 0xc2b2ae35.toInt()
        x = x xor (x ushr 16)
        return (x ushr 8) / 16777216f
    }

    /** Blur kotak 3x (mendekati Gaussian), tepi di-clamp. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val k = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(tmp, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    tmp[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = tmp[y]
            }
        }
    }
}
